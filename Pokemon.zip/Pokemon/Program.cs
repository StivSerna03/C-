﻿using System;

class Pokemon
{    
    public string Nombre { get; set; }
    public string Tipo { get; set; }
    public int Salud { get; set; }
    public int[] Ataques { get; set; } = new int[3];
    public int[] Defensas { get; set; } = new int[2];

    public int Atacar()
    {
        Random random = new Random();
        int ataqueSeleccionado = random.Next(0, 3);
        double multiplicador = random.NextDouble() switch
        {
            var x when x < 0.3 => 1.0,
            var x when x < 0.6 => 0.5,
            _ => 1.5
        };

        return (int)(Ataques[ataqueSeleccionado] * multiplicador);
    }

    public int Defender()
    {
        Random random = new Random();
        int defensaSeleccionada = random.Next(0, 2);
        double multiplicador = random.NextDouble() switch
        {
            var x when x < 0.5 => 1.0,
            _ => 0.5
        };

        return (int)(Defensas[defensaSeleccionada] * multiplicador);
    }
}

class Program
{
    static void Main()
    {
        // Crear a Hitmonlee
        Pokemon hitmonlee = new Pokemon
        {
            Nombre = "Hitmonlee",
            Tipo = "Lucha",
            Salud = 100,
            Ataques = new int[] { 40, 35, 30 },
            Defensas = new int[] { 25, 30 }
        };

        // Crear a Hitmonchan
        Pokemon hitmonchan = new Pokemon
        {
            Nombre = "Hitmonchan",
            Tipo = "Lucha",
            Salud = 100,
            Ataques = new int[] { 38, 32, 37 },
            Defensas = new int[] { 28, 22 }
        };

        // Simular los combates durante 3 turnos
        for (int turno = 1; turno <= 3; turno++)
        {
            int ataqueHitmonlee = hitmonlee.Atacar();
            int defensaHitmonchan = hitmonchan.Defender();
            int danoHitmonlee = Math.Max(0, ataqueHitmonlee - defensaHitmonchan);
            hitmonchan.Salud -= danoHitmonlee;

            int ataqueHitmonchan = hitmonchan.Atacar();
            int defensaHitmonlee = hitmonlee.Defender();
            int danoHitmonchan = Math.Max(0, ataqueHitmonchan - defensaHitmonlee);
            hitmonlee.Salud -= danoHitmonchan;

            Console.WriteLine("Turno " + turno + ":");
            Console.WriteLine(hitmonlee.Nombre + " ataca a " + hitmonchan.Nombre + " y le hace " + danoHitmonlee + " puntos de daño.");
            Console.WriteLine(hitmonchan.Nombre + " ataca a " + hitmonlee.Nombre + " y le hace " + danoHitmonchan + " puntos de daño.");
        }

        // Determinar el ganador o si hay empate
        if (hitmonlee.Salud > hitmonchan.Salud)
        {
            Console.WriteLine(hitmonlee.Nombre + " gana.");
            Console.WriteLine(hitmonlee.Nombre + " es el campeón del ring.");
        }            
        else if (hitmonchan.Salud > hitmonlee.Salud)
            Console.WriteLine(hitmonchan.Nombre + " gana.");
        else
            Console.WriteLine("¡Empate!");

        Console.ReadLine();
    }
}
