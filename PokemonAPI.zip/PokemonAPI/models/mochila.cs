using System.Collections.Generic;

namespace PokemonAPI.Models
{
    public class Mochila
    {
        public List<string>? Objetos { get; set; } = new List<string>();
    }
}
