using System.Collections.Generic;

namespace PokemonAPI.Models
{
    public class Pokedex
    {
        public List<string>? PokemonesRegistrados { get; set; } = new List<string>();
    }
}
